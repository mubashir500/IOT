// Define motor control pins
int LeftMotorForward = 5;
int LeftMotorBackward = 6;
int RightMotorForward = 9;
int RightMotorBackward = 10;

// Define LDR sensor pin
int LDRPin = A5;  // Single LDR

// Variables for LDR sensor readings
int LDRValue = 0;
int thresholdLight = 900;  // Light threshold to detect significant light intensity

void setup() {
  Serial.begin(9600);

  // Motor control pins setup
  pinMode(LeftMotorForward, OUTPUT);
  pinMode(LeftMotorBackward, OUTPUT);
  pinMode(RightMotorForward, OUTPUT);
  pinMode(RightMotorBackward, OUTPUT);

  // LDR sensor pin setup
  pinMode(LDRPin, INPUT);
}

void loop() {
  // Read value from the LDR sensor
  LDRValue = analogRead(LDRPin);

  // Print LDR sensor value for debugging
  Serial.print("LDR Value: ");
  Serial.println(LDRValue);

  // Check light intensity
  if (LDRValue > thresholdLight) {
    // If enough light is detected, move forward
    moveForward();
  } else {
    // If light is weak, rotate to search for light source

    moveStop();
    delay(1000);
    searchForLight();
  }

  delay(100);  // Adjust delay as needed
}

void moveForward() {
  digitalWrite(LeftMotorForward, HIGH);
  digitalWrite(LeftMotorBackward, LOW);
  digitalWrite(RightMotorForward, HIGH);
  digitalWrite(RightMotorBackward, LOW);
}

void moveStop() {
  digitalWrite(LeftMotorForward, LOW);
  digitalWrite(LeftMotorBackward, LOW);
  digitalWrite(RightMotorForward, LOW);
  digitalWrite(RightMotorBackward, LOW);
}

void turnRight() {
  digitalWrite(LeftMotorForward, HIGH);
  digitalWrite(LeftMotorBackward, LOW);
  digitalWrite(RightMotorForward, LOW);
  digitalWrite(RightMotorBackward, HIGH);
  delay(500);  // Adjust delay for turning time
}

void turnLeft() {
  digitalWrite(LeftMotorForward, LOW);
  digitalWrite(LeftMotorBackward, HIGH);
  digitalWrite(RightMotorForward, HIGH);
  digitalWrite(RightMotorBackward, LOW);
  delay(500);  // Adjust delay for turning time
}

void searchForLight() {
  // Rotate to search for a light source
  turnRight();  // You can alternate between left and right for a more comprehensive search
}
